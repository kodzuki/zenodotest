import csv
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("worldpopulation.csv")

location = list(data.iloc[:,0])
years = list(data.columns[1:])

data = data.T
data.columns = location
data = data.iloc[1:,1:]

plt.rcParams['figure.figsize'] = [9, 6]

for loc in location[1:]:
        
        plt.plot(years, data[loc], label = loc, marker = "o", linewidth = 0.5, markersize=3)
        
        plt.xlabel("Year")
        plt.ylabel("Population (%)")
        plt.title("Proportions of Wolrd population predicted")
        
        plt.legend(frameon=False, loc='center right')
        plt.tight_layout()